# Dashboard App

For telemetry, asset inventory, and agent/QA visibility.
