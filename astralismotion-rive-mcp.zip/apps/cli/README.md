# CLI

Entry for scripting MCP-related tasks (generation, sync, QA).
