# MCP Agents

Defines conceptual agent configs for:
- Motion Spec Agent
- Wrapper Generator Agent
- Scene Composer Agent
- Telemetry Agent
- QA Agent
