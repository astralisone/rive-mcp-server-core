# Scene Composer

Parses SceneSpec and generates orchestrated scene components.
