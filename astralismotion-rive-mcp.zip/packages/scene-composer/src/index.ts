export function composeSceneFromSpec(spec: any) {
  // TODO: implement transformation from SceneSpec to framework code.
  return {
    status: "not_implemented",
    spec
  };
}
