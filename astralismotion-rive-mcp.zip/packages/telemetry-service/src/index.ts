export function startTelemetryService() {
  // TODO: implement HTTP server & storage.
  console.log("Telemetry service stub (implement me).");
}
