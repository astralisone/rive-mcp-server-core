# MCP Server: Rive Orchestrator

Skeleton for the Rive MCP Orchestrator:

Tools (intended):
- list_libraries
- list_components
- get_component_detail
- get_runtime_surface
- generate_wrapper
- compose_scene
- collect_metrics
- analyze_performance
