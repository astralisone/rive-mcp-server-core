export async function composeScene(params: any = {}): Promise<any> {
  // TODO: implement using your manifests / storage.
  return {
    status: "not_implemented",
    tool: "composeScene",
    params
  };
}
